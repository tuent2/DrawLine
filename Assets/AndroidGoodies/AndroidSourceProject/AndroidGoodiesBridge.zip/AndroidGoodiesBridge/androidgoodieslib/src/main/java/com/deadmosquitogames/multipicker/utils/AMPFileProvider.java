package com.deadmosquitogames.multipicker.utils;

import androidx.core.content.FileProvider;

/**
 * Created by kbibek on 12/16/16.
 */

public class AMPFileProvider extends FileProvider {
}
