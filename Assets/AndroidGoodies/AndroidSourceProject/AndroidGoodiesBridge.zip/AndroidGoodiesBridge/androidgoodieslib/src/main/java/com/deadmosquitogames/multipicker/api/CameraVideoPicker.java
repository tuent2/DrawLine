package com.deadmosquitogames.multipicker.api;

import android.app.Activity;

import androidx.fragment.app.Fragment;

import com.deadmosquitogames.multipicker.api.exceptions.PickerException;
import com.deadmosquitogames.multipicker.core.VideoPickerImpl;

/**
 * Captures a video using the device's Camera
 */
public class CameraVideoPicker extends VideoPickerImpl {

    /**
     * Constructor for triggering Video capture from an {@link Activity}
     * @param activity
     */
    public CameraVideoPicker(Activity activity) {
        super(activity, Picker.PICK_VIDEO_CAMERA);
    }

    /**
     * Constructor for triggering Video capture from a {@link Fragment}
     * @param fragment
     */
    public CameraVideoPicker(Fragment fragment) {
        super(fragment, Picker.PICK_VIDEO_CAMERA);
    }

    /**
     * Constructor for triggering Video capture from a {@link android.app.Fragment}
     * @param appFragment
     */
    public CameraVideoPicker(android.app.Fragment appFragment) {
        super(appFragment, Picker.PICK_VIDEO_CAMERA);
    }

    /**
     * Re-initialize {@link CameraVideoPicker} object if your activity is destroyed
     * @param activity
     * @param path
     */
    public CameraVideoPicker(Activity activity, String path) {
        super(activity, Picker.PICK_VIDEO_CAMERA);
        reinitialize(path);
    }

    /**
     * Re-initialize {@link CameraVideoPicker} object if your activity is destroyed
     * @param fragment
     * @param path
     */
    public CameraVideoPicker(Fragment fragment, String path) {
        super(fragment, Picker.PICK_VIDEO_CAMERA);
        reinitialize(path);
    }

    /**
     * Re-initialize {@link CameraVideoPicker} object if your activity is destroyed
     * @param appFragment
     * @param path
     */
    public CameraVideoPicker(android.app.Fragment appFragment, String path) {
        super(appFragment, Picker.PICK_VIDEO_CAMERA);
        reinitialize(path);
    }

    /**
     * Trigger Video Capture using the device's Camera
     * @return
     */
    public String pickVideo() {
        String path = null;
        try {
            path = super.pick();
        } catch (PickerException e) {
            e.printStackTrace();
            if (callback != null) {
                callback.onError(e.getMessage());
            }
        }
        return path;
    }
}
