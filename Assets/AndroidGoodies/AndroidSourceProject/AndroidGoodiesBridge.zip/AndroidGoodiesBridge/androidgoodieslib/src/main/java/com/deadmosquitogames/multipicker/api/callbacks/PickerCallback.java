package com.deadmosquitogames.multipicker.api.callbacks;

/**
 * Created by kbibek on 2/24/16.
 */
public interface PickerCallback {
    void onError(String message);
}
