package com.deadmosquitogames.util;

public final class Constants {

	// Image result size
	public static final int IMAGE_RESULT_SIZE_ORIGINAL = 0;
	public static final String LOG_TAG = "AndroidGoodies";

	private Constants() {
	}
}
